DROP SCHEMA IF EXISTS `shop`;
CREATE SCHEMA `shop` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;

CREATE TABLE `shop`.`user` (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(50) NULL DEFAULT NULL,
  `mobile` VARCHAR(15) NULL,
  `email` VARCHAR(50) NULL,
  `passwordHash` VARCHAR(32) NOT NULL,
  `money` decimal(10,2) default 0,
  `isAdmin` BOOLEAN default false,
  `registeredAt` DATETIME NOT NULL,
  UNIQUE INDEX `uq_mobile` (`mobile` ASC),
  UNIQUE INDEX `uq_email` (`email` ASC) );


/*
STATUS
1: sẵn sàng giao dịch ; tạo đơn
2: hủy
3: bên mua đang kiểm tra hàng ; trừ tiền customer
4: hoàn thành  ; cộng tiền createdBy
5: bên mua khiếu nại sản phẩm
6: bên bán đánh dấu khiếu nại không đúng
7: Yêu cầu quản trị viên trung gian
*/
CREATE TABLE `shop`.`order` (
	id BIGINT PRIMARY KEY AUTO_INCREMENT,
    isDelete BOOLEAN,
    createdBy BIGINT,
    deletedBy BIGINT,
    createdAt DATETIME,
    updatedAt DATETIME,
    deletedAt DATETIME,
    contact VARCHAR(255),
    title VARCHAR(255),
    description TEXT,
    isPublic INT,
    hiddenValue TEXT,
    moneyValue INT,
    status INT, 
    isSellerChargeFee INT,
    isPaidToSeller INT,
    customer BIGINT,
    shareLink VARCHAR(255),
    htmlShareLink TEXT,
    feeOnSuccess INT,
    totalMoneyForBuyer INT,
    sellerReceivedOnSuccess INT,
	requestAdmin BIGINT,
    FOREIGN KEY (createdBy) REFERENCES `shop`.`user`(id),
    FOREIGN KEY (customer) REFERENCES `shop`.`user`(id),
    FOREIGN KEY (deletedBy) REFERENCES `shop`.`user`(id),
	FOREIGN KEY (requestAdmin) REFERENCES `shop`.`user`(id)
);

CREATE TABLE `shop`.`recharge` (
	id BIGINT PRIMARY KEY AUTO_INCREMENT,
	userId BIGINT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    method VARCHAR(255) NOT NULL,
	description VARCHAR(255),
    rechargeDate DATETIME NOT NULL,
    FOREIGN KEY (userId) REFERENCES `shop`.`user`(id)
);

CREATE TABLE `shop`.`transaction` (
	id BIGINT PRIMARY KEY AUTO_INCREMENT,
	userId BIGINT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    method VARCHAR(255),
    type VARCHAR(255) NOT NULL,
	description VARCHAR(255),
    rechargeDate DATETIME NOT NULL,
    FOREIGN KEY (userId) REFERENCES `shop`.`user`(id)
);