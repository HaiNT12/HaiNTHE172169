/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Admin
 */
public class HelperUtil {

    public static String getStatusText(int status) {
        switch(status) {
            case 1:
                return "Sẵn sàng giao dịch";
            case 2:
                return "Hủy";
            case 3:
                return "Bên mua đang kiểm tra hàng";
            case 4:
                return "Hoàn thành";
            case 5:
                return "Bên mua khiếu nại sản phẩm";
            case 6:
                return "Bên bán đánh dấu khiếu nại không đúng";
            case 7:
                return "Yêu cầu quản trị viên trung gian";
            case 8:
                return "Chờ bên mua xác nhận khiếu nại không đúng";
            default:
                return "Trạng thái không hợp lệ";
        }
    }
    
    public static String serverUrl(HttpServletRequest request) {
        String host = request.getServerName();
        int port = request.getServerPort();
        String contextPath = request.getContextPath();

        StringBuilder shareLinkBuilder = new StringBuilder();
        shareLinkBuilder.append(request.getScheme()); // http hoặc https
        shareLinkBuilder.append("://");
        shareLinkBuilder.append(host);

        if ((port != 80) && (port != 443)) {
            shareLinkBuilder.append(":").append(port);
        }

        shareLinkBuilder.append(contextPath);
        return shareLinkBuilder.toString();
    }
}
