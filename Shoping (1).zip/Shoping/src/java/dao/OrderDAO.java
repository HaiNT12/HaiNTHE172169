/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import model.Order;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.User;
import util.DbUtil;

/**
 *
 * @author Admin
 */
public class OrderDAO {

    private static final String UPDATE_MONEY_SQL = "UPDATE user SET money = ? WHERE id = ?";
    //=========================================================================================//

    private static final String UPDATE_ORDER_SQL = 
    "UPDATE `shop`.`order` " +
    "SET " +
    "    title = ?, " +
    "    moneyValue = ?, " +
    "    isSellerChargeFee = ?, " +
    "    description = ?, " +
    "    contact = ?, " +
    "    feeOnSuccess = ?, " +
    "    totalMoneyForBuyer = ?, " +
    "    sellerReceivedOnSuccess = ?, " +
    "    updatedAt = ? " +
    "WHERE " +
    "    id = ?";
    private static final String GET_ALL_ORDER_SQL = "SELECT * FROM `shop`.`order`";
    private static final String REQUEST_ADMIN_SQL = "UPDATE `shop`.`order` SET status = 7, updatedAt = ?, requestAdmin = ? WHERE id = ?";
    private static final String WCOMPLAIN_ORDER_SQL = "UPDATE `shop`.`order` SET status = 6, updatedAt = ? WHERE id = ?";
    private static final String CANCEL_ORDER_SQL = "UPDATE `shop`.`order` SET status = 2, updatedAt = ?, customer = ? WHERE id = ?";
    private static final String COMPLAIN_ORDER_SQL = "UPDATE `shop`.`order` SET status = 5, updatedAt = ? WHERE id = ?";
    private static final String CONFIRM_ORDER_SQL = "UPDATE `shop`.`order` SET status = 4, updatedAt = ? WHERE id = ?";
    private static final String BUY_SQL = "UPDATE `shop`.`order` SET status = 3, updatedAt = ?, customer = ? WHERE id = ?";
    private static final String SELECT_BUY_ORDER_BY_USER_SQL = "SELECT * FROM `shop`.`order` WHERE customer = ?";
    private static final String SELECT_ORDER_BY_ID_SQL = "SELECT * FROM `shop`.`order` where id = ?";
    private static final String SELECT_ALL_PUBLIC_ORDERS_SQL = "SELECT * FROM `shop`.`order` where isPublic = 1 and status = 1";
    private static final String SELECT_SELL_ORDERS_BY_USER_SQL = "SELECT * FROM `shop`.`order` WHERE createdBy = ?";
    private static final String CREATE_ORDER_SQL
            = "INSERT INTO `shop`.`order` "
            + "(isDelete, createdBy, createdAt, updatedAt, "
            + "contact, title, description, isPublic, hiddenValue, moneyValue, "
            + "status, isSellerChargeFee, isPaidToSeller, shareLink, "
            + "htmlShareLink, feeOnSuccess, totalMoneyForBuyer, sellerReceivedOnSuccess "
            + ") "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    public void updateOrder(Order order){
        try (Connection connection = DbUtil.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_ORDER_SQL)) {
            preparedStatement.setString(1, order.getTitle());
            preparedStatement.setInt(2, order.getMoneyValue());
            preparedStatement.setInt(3, order.getIsSellerChargeFee());
            preparedStatement.setString(4, order.getDescription());
            preparedStatement.setString(5, order.getContact());
            preparedStatement.setInt(6, order.getFeeOnSuccess());
            preparedStatement.setInt(7, order.getTotalMoneyForBuyer());
            preparedStatement.setInt(8, order.getSellerReceivedOnSuccess());
            preparedStatement.setTimestamp(9, new Timestamp(new java.util.Date().getTime()));
            preparedStatement.setLong(10, order.getId());
            

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }
    }
    
    public void requestAdmin(long orderId, User user) {
        Connection connection = null;
        try {
            connection = DbUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(REQUEST_ADMIN_SQL);
            PreparedStatement preparedStatement1 = connection.prepareStatement(UPDATE_MONEY_SQL);
            connection.setAutoCommit(false);

            // Thực hiện khiếu nại
            preparedStatement.setTimestamp(1, new Timestamp(new java.util.Date().getTime()));
            preparedStatement.setLong(2, user.getId());
            preparedStatement.setLong(3, orderId);
            preparedStatement.executeUpdate();
            // Thực thi sql khiếu nại
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                //===== thực hiện trừ tiền ===============//
                if (user.getMoney() < 50000) {
                    throw new SQLException("Money not enough!!!");
                }
                preparedStatement1.setDouble(1, user.getMoney() - 50000);
                preparedStatement1.setLong(2, user.getId());

                // Thực thi câu lệnh SQL trừ tiền
                preparedStatement1.executeUpdate();
                connection.commit();
            } else {
                System.out.println("Failed to wcomplain order with ID: " + orderId);
                connection.rollback();
            }

        } catch (SQLException e) {
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            // Xử lý ngoại lệ một cách phù hợp (ghi log, ném ngoại lệ, vv.)
        } finally {
            // Đóng kết nối
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void wComplainOrder(long orderId) {
        Connection connection = null;
        try {
            connection = DbUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(WCOMPLAIN_ORDER_SQL);
            connection.setAutoCommit(false);

            // Thực hiện khiếu nại
            preparedStatement.setTimestamp(1, new Timestamp(new java.util.Date().getTime()));
            preparedStatement.setLong(2, orderId);
            preparedStatement.executeUpdate();
            // Thực thi sql khiếu nại
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {

                connection.commit();
            } else {
                System.out.println("Failed to wcomplain order with ID: " + orderId);
                connection.rollback();
            }

        } catch (SQLException e) {
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            // Xử lý ngoại lệ một cách phù hợp (ghi log, ném ngoại lệ, vv.)
        } finally {
            // Đóng kết nối
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void cancelOrder(long orderId, User customer) {
        Connection connection = null;

        try {
            connection = DbUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(CANCEL_ORDER_SQL);
            PreparedStatement preparedStatement1 = connection.prepareStatement(UPDATE_MONEY_SQL);
            connection.setAutoCommit(false);

            //Thực hiện mua hàng
            preparedStatement.setTimestamp(1, new Timestamp(new java.util.Date().getTime()));
            preparedStatement.setLong(2, customer.getId());
            preparedStatement.setLong(3, orderId);

            // Thực thi câu lệnh SQL mua hàng
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                // Nếu cập nhật thành công, trả về đơn hàng đã mua
                Order result = getOrderById(orderId);

                //===== thực hiện trả tiền ===============//
                preparedStatement1.setDouble(1, customer.getMoney() + result.getTotalMoneyForBuyer());
                preparedStatement1.setLong(2, customer.getId());

              
                // Thực thi câu lệnh SQL trả tiền
                preparedStatement1.executeUpdate();

                connection.commit();
            } else {
                connection.rollback();
            }

        } catch (SQLException e) {
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            // Xử lý ngoại lệ một cách phù hợp (ghi log, ném ngoại lệ, vv.)
        } finally {
            // Đóng kết nối
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void complainOrder(long orderId) {
        Connection connection = null;
        try {
            connection = DbUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(COMPLAIN_ORDER_SQL);
            connection.setAutoCommit(false);

            // Thực hiện khiếu nại
            preparedStatement.setTimestamp(1, new Timestamp(new java.util.Date().getTime()));
            preparedStatement.setLong(2, orderId);
            preparedStatement.executeUpdate();
            // Thực thi sql khiếu nại
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {

                connection.commit();
            } else {
                System.out.println("Failed to complain order with ID: " + orderId);
                connection.rollback();
            }

        } catch (SQLException e) {
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            // Xử lý ngoại lệ một cách phù hợp (ghi log, ném ngoại lệ, vv.)
        } finally {
            // Đóng kết nối
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void confirmOrder(long orderId, User createdBy,boolean isAdmin) {
        Connection connection = null;
        try {
            connection = DbUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(CONFIRM_ORDER_SQL);
            PreparedStatement preparedStatement1 = connection.prepareStatement(UPDATE_MONEY_SQL);
            PreparedStatement preparedStatement2 = connection.prepareStatement(UPDATE_MONEY_SQL);
            connection.setAutoCommit(false);

            // Thực hiện xác nhận
            preparedStatement.setTimestamp(1, new Timestamp(new java.util.Date().getTime()));
            preparedStatement.setLong(2, orderId);
            preparedStatement.executeUpdate();
            // Thực thi sql xác nhận
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                // Nếu cập nhật thành công, trả về đơn hàng đã mua
                Order result = getOrderById(orderId);

                //===== thực hiện cộng tiền ===============//
                preparedStatement1.setDouble(1, createdBy.getMoney() + result.getSellerReceivedOnSuccess());
                preparedStatement1.setLong(2, createdBy.getId());

                // Thực thi câu lệnh SQL trừ tiền
                preparedStatement1.executeUpdate();
                
                                
                
                if(result.getRequestAdmin() != null && isAdmin == true){
                    UserDAO userDao = new UserDAO();
                    User requestAdmin = userDao.getUserById(result.getRequestAdmin());
                    preparedStatement2.setDouble(1, requestAdmin.getMoney() + 50000);
                    preparedStatement2.setLong(2, requestAdmin.getId());
                }
                connection.commit();
            } else {
                System.out.println("Failed to confirm order with ID: " + orderId);
                connection.rollback();
            }

        } catch (SQLException e) {
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            // Xử lý ngoại lệ một cách phù hợp (ghi log, ném ngoại lệ, vv.)
        } finally {
            // Đóng kết nối
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Order buyOrder(long orderId, User customer) throws SQLException {
        Connection connection = null;
        Order result = null;
        try {
            connection = DbUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(BUY_SQL);
            PreparedStatement preparedStatement1 = connection.prepareStatement(UPDATE_MONEY_SQL);
            connection.setAutoCommit(false);

            //Thực hiện mua hàng
            preparedStatement.setTimestamp(1, new Timestamp(new java.util.Date().getTime()));
            preparedStatement.setLong(2, customer.getId());
            preparedStatement.setLong(3, orderId);

            // Thực thi câu lệnh SQL mua hàng
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                // Nếu cập nhật thành công, trả về đơn hàng đã mua
                result = getOrderById(orderId);

                //===== thực hiện giam tiền ===============//
                if (customer.getMoney() < result.getTotalMoneyForBuyer()) {
                    throw new SQLException("Money not enough!!!");
                }
                preparedStatement1.setDouble(1, customer.getMoney() - result.getTotalMoneyForBuyer());
                preparedStatement1.setLong(2, customer.getId());

                // Thực thi câu lệnh SQL trừ tiền
                preparedStatement1.executeUpdate();
                connection.commit();
            } else {
                System.out.println("Failed to buy order with ID: " + orderId);
                System.out.println("Failed to buy customer with ID: " + customer);
                connection.rollback();
            }

        } catch (SQLException e) {
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            
            e.printStackTrace();
            throw e;
            // Xử lý ngoại lệ một cách phù hợp (ghi log, ném ngoại lệ, vv.)
        } finally {
            // Đóng kết nối
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public List<Order> getBuyOrderByUser(long userId) {
        List<Order> orderList = new ArrayList<>();

        try (Connection connection = DbUtil.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BUY_ORDER_BY_USER_SQL)) {

            preparedStatement.setLong(1, userId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    Order order = mapResultSetToOrder(resultSet);
                    orderList.add(order);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }

        return orderList;
    }

    public List<Order> getSellOrderByUser(long userId) {
        List<Order> orderList = new ArrayList<>();

        try (Connection connection = DbUtil.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_SELL_ORDERS_BY_USER_SQL)) {

            preparedStatement.setLong(1, userId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    Order order = mapResultSetToOrder(resultSet);
                    orderList.add(order);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }

        return orderList;
    }

    public Order getOrderById(long orderId) {
        Order order = null;
        try (Connection connection = DbUtil.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ORDER_BY_ID_SQL)) {

            preparedStatement.setLong(1, orderId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    order = mapResultSetToOrder(resultSet);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }

        return order;
    }

    public List<Order> getAllPublic() {
        List<Order> orderList = new ArrayList<>();

        try (Connection connection = DbUtil.getConnection(); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery(SELECT_ALL_PUBLIC_ORDERS_SQL)) {

            while (resultSet.next()) {
                Order order = mapResultSetToOrder(resultSet);
                orderList.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }

        return orderList;
    }
    public List<Order> getAll() {
        List<Order> orderList = new ArrayList<>();

        try (Connection connection = DbUtil.getConnection(); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery(GET_ALL_ORDER_SQL)) {

            while (resultSet.next()) {
                Order order = mapResultSetToOrder(resultSet);
                orderList.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }

        return orderList;
    }

    public Order addOrder(Order order, User createdBy) {
        Connection connection = null;
        Order result = null;
        try {
            connection = DbUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(CREATE_ORDER_SQL, Statement.RETURN_GENERATED_KEYS);
            PreparedStatement preparedStatement1 = connection.prepareStatement(UPDATE_MONEY_SQL);
            connection.setAutoCommit(false);

            preparedStatement.setBoolean(1, order.getIsDelete());
            preparedStatement.setString(2, order.getCreatedBy());
            preparedStatement.setTimestamp(3, new Timestamp(order.getCreatedAt().getTime()));
            preparedStatement.setTimestamp(4, new Timestamp(order.getUpdatedAt().getTime()));
            preparedStatement.setString(5, order.getContact());
            preparedStatement.setString(6, order.getTitle());
            preparedStatement.setString(7, order.getDescription());
            preparedStatement.setInt(8, order.getIsPublic());
            preparedStatement.setString(9, order.getHiddenValue());
            preparedStatement.setInt(10, order.getMoneyValue());
            preparedStatement.setInt(11, order.getStatus());
            preparedStatement.setInt(12, order.getIsSellerChargeFee());
            preparedStatement.setInt(13, order.getIsPaidToSeller());
            preparedStatement.setString(14, order.getShareLink());
            preparedStatement.setString(15, order.getHtmlShareLink());
            preparedStatement.setInt(16, order.getFeeOnSuccess());
            preparedStatement.setInt(17, order.getTotalMoneyForBuyer());
            preparedStatement.setInt(18, order.getSellerReceivedOnSuccess());


            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        long orderId = generatedKeys.getLong(1);
                        // Retrieve the newly added order using the getOrderById method
                        

                        if (createdBy.getMoney() < 500) {
                            throw new SQLException("Money not enough!!!");
                        }
                        //===== thực hiện trả tiền ===============//
                        preparedStatement1.setDouble(1, createdBy.getMoney() - 500);
                        preparedStatement1.setLong(2, createdBy.getId());
                        preparedStatement1.executeUpdate();
                        connection.commit();
                        result = getOrderById(orderId);
                    } else {
                        System.out.println("Failed to retrieve generated keys.");
                        connection.rollback();
                    }
                }
            } else {
                System.out.println("No user found with the provided ID.");
                connection.rollback();
            }
        } catch (SQLException e) {
           try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            // Xử lý ngoại lệ một cách phù hợp (ghi log, ném ngoại lệ, vv.)
        } finally {
            // Đóng kết nối
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public Order mapResultSetToOrder(ResultSet resultSet) throws SQLException {
        Order order = new Order();
        order.setId(resultSet.getLong("id"));
        order.setIsDelete(resultSet.getBoolean("isDelete"));
        order.setCreatedBy(resultSet.getString("createdBy"));
        order.setDeletedBy(resultSet.getString("deletedBy"));
        order.setCreatedAt(resultSet.getTimestamp("createdAt"));
        order.setUpdatedAt(resultSet.getTimestamp("updatedAt"));
        order.setDeletedAt(resultSet.getTimestamp("deletedAt"));
        order.setContact(resultSet.getString("contact"));
        order.setTitle(resultSet.getString("title"));
        order.setDescription(resultSet.getString("description"));
        order.setIsPublic(resultSet.getInt("isPublic"));
        order.setHiddenValue(resultSet.getString("hiddenValue"));
        order.setMoneyValue(resultSet.getInt("moneyValue"));
        order.setStatus(resultSet.getInt("status"));
        order.setIsSellerChargeFee(resultSet.getInt("isSellerChargeFee"));
        order.setIsPaidToSeller(resultSet.getInt("isPaidToSeller"));
        order.setCustomer(resultSet.getLong("customer"));
        order.setShareLink(resultSet.getString("shareLink"));
        order.setHtmlShareLink(resultSet.getString("htmlShareLink"));
        order.setFeeOnSuccess(resultSet.getInt("feeOnSuccess"));
        order.setTotalMoneyForBuyer(resultSet.getInt("totalMoneyForBuyer"));
        order.setSellerReceivedOnSuccess(resultSet.getInt("sellerReceivedOnSuccess"));
        order.setRequestAdmin(resultSet.getLong("requestAdmin"));
        return order;
    }
}
