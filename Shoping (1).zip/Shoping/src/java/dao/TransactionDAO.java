/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Transaction;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import util.DbUtil;

/**
 *
 * @author Admin
 */
public class TransactionDAO {
    
    private static final String ADD_TRNASCTION_SQL = "INSERT INTO `shop`.`transaction` (userId, amount, method, description, rechargeDate, type) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String GET_TRANSACTIONS_BY_USER_SQL = "SELECT * FROM `shop`.`transaction` WHERE userId = ?";

    public List<Transaction> getTransactionsByUser(long userId) {
        List<Transaction> transactions = new ArrayList<>();

        try (Connection connection = DbUtil.getConnection(); PreparedStatement statement = connection.prepareStatement(GET_TRANSACTIONS_BY_USER_SQL)) {
            statement.setLong(1, userId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Transaction transaction = mapResultSetToTransaction(resultSet);
                    transactions.add(transaction);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }

        return transactions;
    }
    
    public void addTransaction(Transaction transaction){
    
       try (Connection connection = DbUtil.getConnection(); PreparedStatement statement = connection.prepareStatement(ADD_TRNASCTION_SQL)) {

            statement.setLong(1, transaction.getUserId());
            statement.setDouble(2, transaction.getAmount());
            statement.setString(3, transaction.getMethod());
            statement.setString(4, transaction.getDescription());
            statement.setTimestamp(5, new Timestamp(transaction.getRechargeDate().getTime()));
            statement.setString(6, transaction.getType());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }
    }
    
    
    
    public Transaction mapResultSetToTransaction(ResultSet resultSet) throws SQLException {
        Transaction transaction = new Transaction();
        transaction.setId(resultSet.getLong("id"));
        transaction.setUserId(resultSet.getLong("userId"));
        transaction.setAmount(resultSet.getDouble("amount"));
        transaction.setMethod(resultSet.getString("method"));
        transaction.setDescription(resultSet.getString("description"));
        transaction.setRechargeDate(resultSet.getTimestamp("rechargeDate"));
        transaction.setType(resultSet.getString("type"));
        return transaction;
    }
}
