/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.User;
import java.sql.*;
import util.DbUtil;

/**
 *
 * @author Admin
 */
public class UserDAO {

    private static final String UPDATE_MONEY_SQL = "UPDATE user SET money = ? WHERE id = ?";
    private static final String CHECK_LOGIN_SQL = "SELECT * FROM user WHERE email = ? AND passwordHash = ?";
    private static final String REGISTER_USER_SQL = "INSERT INTO user (name, email, passwordHash, registeredAt) VALUES (?, ?, ?, ?)";
    private static final String UPDATE_PROFILE_SQL = "UPDATE user SET name = ?, mobile = ? WHERE id = ?";
    private static final String GET_USER_BY_ID_SQL = "SELECT * FROM user where id = ?";
    private static final String CHANGE_PASSWORD_SQL = "UPDATE user SET passwordHash = ? WHERE id = ?";

    public User changePassword(String password, long userId) {
        User user = null;
        try (Connection connection = DbUtil.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(CHANGE_PASSWORD_SQL)) {

            preparedStatement.setString(1, password);
            preparedStatement.setLong(2, userId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                user = getUserById(userId);
            } else {
                System.out.println("No user found with the provided ID.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }
        return user;
    }

    public User updateProfile(String name, String mobile, long userId) {
        User user = null;
        try (Connection connection = DbUtil.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_PROFILE_SQL)) {

            preparedStatement.setString(1, name);
            preparedStatement.setString(2, mobile);
            preparedStatement.setLong(3, userId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                user = getUserById(userId);
            } else {
                System.out.println("No user found with the provided ID.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }
        return user;
    }

    public User getUserById(long userId) {
        User user = null;
        try (Connection connection = DbUtil.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(GET_USER_BY_ID_SQL)) {

            preparedStatement.setLong(1, userId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    user = mapResultSetToUser(resultSet);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }

        return user;
    }

    public void register(String name, String email, String password) {
        try (Connection connection = DbUtil.getConnection(); PreparedStatement statement = connection.prepareStatement(REGISTER_USER_SQL)) {

            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, password);
            statement.setTimestamp(4, new Timestamp(System.currentTimeMillis()));

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }

    }

    public User checkLogin(String email, String password) {
        try (Connection connection = DbUtil.getConnection(); PreparedStatement statement = connection.prepareStatement(CHECK_LOGIN_SQL)) {

            statement.setString(1, email);
            statement.setString(2, password);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapResultSetToUser(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }

        return null;
    }


    public User mapResultSetToUser(ResultSet resultSet) throws SQLException {
        User user = new User();
        user.setId(resultSet.getLong("id"));
        user.setName(resultSet.getString("name"));
        user.setMobile(resultSet.getString("mobile"));
        user.setEmail(resultSet.getString("email"));
        user.setMoney(resultSet.getDouble("money"));
        user.setPasswordHash(resultSet.getString("passwordHash"));
        user.setRegisteredAt(resultSet.getTimestamp("registeredAt"));
        user.setIsAdmin(resultSet.getBoolean("isAdmin"));
        return user;
    }
}
