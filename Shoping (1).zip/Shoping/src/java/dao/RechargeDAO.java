/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import model.Recharge;
import model.User;
import util.DbUtil;

/**
 *
 * @author Admin
 */
public class RechargeDAO {

    private static final String UPDATE_MONEY_SQL = "UPDATE user SET money = ? WHERE id = ?";
    private static final String RECHARGE_MONEY_SQL
            = "INSERT INTO `shop`.`recharge` "
            + "(userId, amount, description, rechargeDate, method) "
            + "VALUES (?, ?, ?, ?, ?)";

    public void rechargeMoney(Recharge rechagre,User user) {
        try (
            Connection connection = DbUtil.getConnection(); 
            PreparedStatement preparedStatement = connection.prepareStatement(RECHARGE_MONEY_SQL); 
            PreparedStatement preparedStatement1 = connection.prepareStatement(UPDATE_MONEY_SQL);
            ) {
            preparedStatement.setLong(1, rechagre.getUserId());
            preparedStatement.setDouble(2, rechagre.getAmount());
            preparedStatement.setString(3, rechagre.getDescription());
            preparedStatement.setTimestamp(4, new Timestamp(rechagre.getRechargeDate().getTime()));
            preparedStatement.setString(5, rechagre.getMethod());
            preparedStatement.executeUpdate();

            preparedStatement1.setDouble(1, user.getMoney() + rechagre.getAmount());
            preparedStatement1.setLong(2, user.getId());
            preparedStatement1.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately (log, throw, etc.)
        }
    }
}
