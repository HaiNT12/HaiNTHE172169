/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Admin
 */
public class MainController extends HttpServlet {

    private static final String LOGIN = "LoginController";
    private static final String LOGOUT = "LogoutController";
    private static final String UPDATE_PROFILE = "UpdateProfileController";
    private static final String REGISTER = "RegisterController";
    private static final String CHANGE_PASSWORD = "ChangePasswordController";
    private static final String CREATE_ORDER = "CreateOrderController";
    private static final String GET_ORDER = "GetOrderDetail";
    private static final String BUY_ORDER = "BuyController";
    private static final String CONFIRM_ORDER = "ConfirmOrderController";
    private static final String COMPLAIN_ORDER = "ComplainOrderController";
    private static final String CANCEL_ORDER = "CancelOrderControler";
    private static final String WCOMPLAIN_ORDER = "WComplainOrderController";
    private static final String REQUEST_ADMIN = "RequestAdminController";
    private static final String RECHARGE = "RechargeController";
    private static final String UPDATE_ORDER = "UpdateOrderController";
    private static final String ERROR = "invalid.html";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        String url = ERROR;
        try {
            String action = request.getParameter("btnAction");
            if (action.equals("Login")) {
                url = LOGIN;
            } else if (action.equals("Register")) {
                url = REGISTER;
            } else if (action.equals("Logout")) {
                url = LOGOUT;
            } else if (action.equals("UpdateProfile")) {
                url = UPDATE_PROFILE;
            } else if (action.equals("ChangePassword")) {
                url = CHANGE_PASSWORD;
            } else if (action.equals("CreateOrder")) {
                url = CREATE_ORDER;
            } else if (action.equals("GetOrder")) {
                url = GET_ORDER;
            } else if (action.equals("BuyOrder")) {
                url = BUY_ORDER;
            } else if (action.equals("ConfirmOrder")) {
                url = CONFIRM_ORDER;
            } else if (action.equals("ComplainOrder")) {
                url = COMPLAIN_ORDER;
            } else if (action.equals("CancelOrder")) {
                url = CANCEL_ORDER;
            } else if (action.equals("WComplainOrder")) {
                url = WCOMPLAIN_ORDER;
            } else if (action.equals("RequestAdmin")) {
                url = REQUEST_ADMIN;
            } else if (action.equals("Recharge")) {
                url = RECHARGE;
            }   else if (action.equals("UpdateOrder")) {
                url = UPDATE_ORDER;
            }
        } catch (Exception e) {
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
