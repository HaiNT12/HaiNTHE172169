/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import static controller.UpdateProfileController.ERROR;
import static controller.UpdateProfileController.SUCCESS;
import dao.RechargeDAO;
import dao.TransactionDAO;
import dao.UserDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Recharge;
import model.Transaction;
import model.User;

/**
 *
 * @author Admin
 */
public class RechargeController extends HttpServlet {

    public static final String SUCCESS = "deposit";
    public static final String ERROR = "deposit";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(true);
        User oldUser = (User) session.getAttribute("USER");
        String url = ERROR;
        try {
            Date rechargeDate = new Date();
            String method = request.getParameter("method");
            String description = request.getParameter("description");
            String txtAmount = request.getParameter("amount").replaceAll("[^\\d]", "");
            UserDAO userDAO = new UserDAO();
            RechargeDAO rechargeDAO = new RechargeDAO();
            TransactionDAO tranasctionDAO = new TransactionDAO();
            Recharge recharge = new Recharge();
            recharge.setAmount(Double.valueOf(txtAmount));
            recharge.setDescription(description);
            recharge.setRechargeDate(rechargeDate);
            recharge.setUserId(oldUser.getId());
            recharge.setMethod(method);

            rechargeDAO.rechargeMoney(recharge,userDAO.getUserById(oldUser.getId()));
            
            
            Transaction transaction = new Transaction();
            transaction.setAmount(Double.valueOf(txtAmount));
            transaction.setDescription(description);
            transaction.setMethod(method);
            transaction.setRechargeDate(rechargeDate);
            transaction.setUserId(oldUser.getId());
            transaction.setType("+");
            tranasctionDAO.addTransaction(transaction);
            User user = userDAO.getUserById(oldUser.getId());
            if (user != null) {
                session.setAttribute("USER", user);
                url = SUCCESS;
            } else {
                url = ERROR;
            }

        } catch (Exception e) {
            log("error at update servlet: " + e.toString());
        } finally {
            response.sendRedirect(url);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
