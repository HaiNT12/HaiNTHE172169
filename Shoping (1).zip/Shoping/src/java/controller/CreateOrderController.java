/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.OrderDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Order;
import model.User;
import util.HelperUtil;
import com.google.gson.Gson;
import dao.TransactionDAO;
import dao.UserDAO;
import model.Transaction;

/**
 *
 * @author Admin
 */
public class CreateOrderController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            HttpSession session = request.getSession(false);
            User user = (User) session.getAttribute("USER");
            // Lấy thông tin từ request (title, price, category, description, ...)
            String title = request.getParameter("title");
            Integer price = Integer.parseInt(request.getParameter("price").replaceAll("[^\\d]", ""));
            Integer isSellerChargeFee = Integer.valueOf(request.getParameter("isSellerChargeFee"));
            String description = request.getParameter("description");
            String contact = request.getParameter("contact");
            Integer isPublic = Integer.valueOf(request.getParameter("isPublic"));
            String hiddenValue = request.getParameter("hiddenValue");
            // Lấy thông tin khác tương tự
            Date currentDate = new Date();
            OrderDAO dao = new OrderDAO();
            Order order = new Order();
            order.setTitle(title);
            order.setMoneyValue(price);
            order.setIsSellerChargeFee(isSellerChargeFee);
            order.setDescription(description);
            order.setContact(contact);
            order.setIsPublic(isPublic);
            order.setHiddenValue(hiddenValue);
            
            order.setIsDelete(false);
            order.setCreatedBy(String.valueOf(user.getId()));
            order.setCreatedAt(currentDate);
            order.setUpdatedAt(currentDate);
            order.setStatus(1);
            order.setIsPaidToSeller(0);
            order.setShareLink(HelperUtil.serverUrl(request));
            order.setHtmlShareLink(HelperUtil.serverUrl(request));
            order.setFeeOnSuccess((int) Math.round(0.05 * price));
            
            order.setTotalMoneyForBuyer(isSellerChargeFee == 1 ? price : order.getFeeOnSuccess() + price);
            order.setSellerReceivedOnSuccess(isSellerChargeFee == 1 ? price - order.getFeeOnSuccess() : price);
      
            UserDAO userDao = new UserDAO();
            Order success = dao.addOrder(order, userDao.getUserById(user.getId()));
            if (success != null) {
                TransactionDAO transactionDAO = new TransactionDAO();
                Transaction transaction = new Transaction();
                
                transaction.setAmount(Double.valueOf(500));
                transaction.setDescription("Trừ 500đ phí tạo đơn");
                transaction.setRechargeDate(success.getCreatedAt());
                transaction.setUserId(user.getId());
                transaction.setType("-");
                
                session.setAttribute("USER", userDao.getUserById(user.getId()));
                
                transactionDAO.addTransaction(transaction);
                Gson gson = new Gson();
                String orderJson = gson.toJson(success);
                out.print(orderJson);
            } else {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write(new Gson().toJson("Có lỗi xảy ra khi tạo đơn hàng."));
            }
            
        } catch (Exception e) {
            out.print("Có lỗi xảy ra khi xử lý yêu cầu.");
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
