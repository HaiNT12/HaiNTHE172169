/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.UserDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.User;

/**
 *
 * @author Admin
 */
public class ChangePasswordController extends HttpServlet {

    public static final String SUCCESS = "profile";
    public static final String ERROR = "profile";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(true);
        String url = ERROR;
        try {
            Integer id = Integer.valueOf(request.getParameter("id"));
            String oldPwd = request.getParameter("oldPwd");
            String newPwd = request.getParameter("newPwd");
            String confirmPwd = request.getParameter("confirmPwd");
            if (!newPwd.equals(confirmPwd)) {
                url = ERROR + "?changePasswordError=" + URLEncoder.encode("Mật khẩu xác thực không đúng", "UTF-8");
            } else {
                UserDAO dao = new UserDAO();
                User oldUser = dao.getUserById(id);
                if (oldUser.getPasswordHash().equals(oldPwd)) {
                    User newUser = dao.changePassword(newPwd, id);
                    if (newUser != null) {
                        session.setAttribute("USER", newUser);
                        url = SUCCESS;
                    } else {
                        url = ERROR;
                    }
                }else{
                    url = ERROR + "?changePasswordError=" + URLEncoder.encode("Mật khẩu cũ không đúng", "UTF-8");
                }

            }

        } catch (Exception e) {
            log("error at change password servlet: " + e.toString());
        } finally {
            response.sendRedirect(url);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
