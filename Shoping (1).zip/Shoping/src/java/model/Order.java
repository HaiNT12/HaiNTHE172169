/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author Admin
 */
public class Order {

    private Long id;
    private Boolean isDelete;
    private String createdBy;
    private String deletedBy;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
    private String contact;
    private String title;
    private String description;
    private Integer isPublic;
    private String hiddenValue;
    private Integer moneyValue;
    private Integer status;
    private Integer isSellerChargeFee;
    private Integer isPaidToSeller;
    private Long customer;
    private String shareLink;
    private String htmlShareLink;
    private Integer feeOnSuccess;
    private Integer totalMoneyForBuyer;
    private Integer sellerReceivedOnSuccess;
    private Long requestAdmin;

    // dto
    private User customerDto;
    private User createdByDto;
    
    public Order() {
    }

    public Long getRequestAdmin() {
        return requestAdmin;
    }

    public void setRequestAdmin(Long requestAdmin) {
        this.requestAdmin = requestAdmin;
    }

    
    public User getCustomerDto() {
        return customerDto;
    }

    public void setCustomerDto(User customerDto) {
        this.customerDto = customerDto;
    }

    public User getCreatedByDto() {
        return createdByDto;
    }

    public void setCreatedByDto(User createdByDto) {
        this.createdByDto = createdByDto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Boolean isDelete) {
        this.isDelete = isDelete;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getIsPublic() {
        return isPublic;
    }

    public void setIsPublic(Integer isPublic) {
        this.isPublic = isPublic;
    }

    public String getHiddenValue() {
        return hiddenValue;
    }

    public void setHiddenValue(String hiddenValue) {
        this.hiddenValue = hiddenValue;
    }

    public Integer getMoneyValue() {
        return moneyValue;
    }

    public void setMoneyValue(Integer moneyValue) {
        this.moneyValue = moneyValue;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getIsSellerChargeFee() {
        return isSellerChargeFee;
    }

    public void setIsSellerChargeFee(Integer isSellerChargeFee) {
        this.isSellerChargeFee = isSellerChargeFee;
    }

    public Integer getIsPaidToSeller() {
        return isPaidToSeller;
    }

    public void setIsPaidToSeller(Integer isPaidToSeller) {
        this.isPaidToSeller = isPaidToSeller;
    }

    public Long getCustomer() {
        return customer;
    }

    public void setCustomer(Long customer) {
        this.customer = customer;
    }

    public String getShareLink() {
        return shareLink;
    }

    public void setShareLink(String shareLink) {
        this.shareLink = shareLink;
    }

    public String getHtmlShareLink() {
        return htmlShareLink;
    }

    public void setHtmlShareLink(String htmlShareLink) {
        this.htmlShareLink = htmlShareLink;
    }

    public Integer getFeeOnSuccess() {
        return feeOnSuccess;
    }

    public void setFeeOnSuccess(Integer feeOnSuccess) {
        this.feeOnSuccess = feeOnSuccess;
    }

    public Integer getTotalMoneyForBuyer() {
        return totalMoneyForBuyer;
    }

    public void setTotalMoneyForBuyer(Integer totalMoneyForBuyer) {
        this.totalMoneyForBuyer = totalMoneyForBuyer;
    }

    public Integer getSellerReceivedOnSuccess() {
        return sellerReceivedOnSuccess;
    }

    public void setSellerReceivedOnSuccess(Integer sellerReceivedOnSuccess) {
        this.sellerReceivedOnSuccess = sellerReceivedOnSuccess;
    }

   
}
